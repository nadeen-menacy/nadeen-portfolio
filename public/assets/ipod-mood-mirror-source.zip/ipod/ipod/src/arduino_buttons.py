"""
Arduino button interface for iPod Mood Mirror
Reads button states from Arduino via USB serial
"""

import serial
import serial.tools.list_ports
import threading
import time


class ArduinoButtonInterface:
    """Interface for Arduino-based physical buttons"""
    
    def __init__(self, baudrate=9600):
        self.serial_port = None
        self.baudrate = baudrate
        self.callbacks = {}
        self.volume_callback = None
        self.running = False
        self.read_thread = None
        
        # Try to find and connect to Arduino
        self._connect_arduino()
    
    def _find_arduino_port(self):
        """Auto-detect Arduino COM port"""
        ports = serial.tools.list_ports.comports()
        
        for port in ports:
            # Look for Arduino-like devices
            if 'Arduino' in port.description or 'CH340' in port.description or 'USB Serial' in port.description:
                return port.device
        
        # If no Arduino found, return None
        return None
    
    def _connect_arduino(self):
        """Connect to Arduino via serial"""
        try:
            port = self._find_arduino_port()
            
            if port:
                self.serial_port = serial.Serial(port, self.baudrate, timeout=1)
                time.sleep(2)  # Wait for Arduino to reset
                print(f"✅ Arduino connected on {port}")
                return True
            else:
                print("⚠️  Arduino not found - buttons disabled")
                print("   Connect Arduino and restart, or use web interface only")
                return False
                
        except Exception as e:
            print(f"⚠️  Could not connect to Arduino: {e}")
            print("   Using web interface only")
            return False
    
    def start(self):
        """Start reading from Arduino"""
        if not self.serial_port:
            return False
        
        self.running = True
        self.read_thread = threading.Thread(target=self._read_loop)
        self.read_thread.daemon = True
        self.read_thread.start()
        return True
    
    def _read_loop(self):
        """Continuously read button states from Arduino"""
        while self.running and self.serial_port:
            try:
                if self.serial_port.in_waiting > 0:
                    line = self.serial_port.readline().decode('utf-8').strip()
                    self._process_command(line)
            except Exception as e:
                print(f"⚠️  Arduino read error: {e}")
                time.sleep(0.1)
    
    def _process_command(self, command):
        """Process commands from Arduino"""
        # Expected format: "MOOD:jazz", "VOLUME:+1", "VOLUME:-1"
        
        if ':' not in command:
            return
        
        cmd_type, cmd_value = command.split(':', 1)
        
        if cmd_type == 'MOOD':
            # Mood button pressed
            mood = cmd_value.lower()
            if mood in self.callbacks:
                print(f"🔘 Physical button: {mood}")
                self.callbacks[mood](mood)
        
        elif cmd_type == 'VOLUME':
            # Volume knob turned
            if self.volume_callback:
                direction = 1 if cmd_value == '+1' else -1
                print(f"🎚️  Physical knob: {'↑' if direction > 0 else '↓'}")
                self.volume_callback(direction)
    
    def register_callback(self, mood_key, callback_func):
        """Register callback for mood button"""
        self.callbacks[mood_key] = callback_func
    
    def register_volume_callback(self, callback_func):
        """Register callback for volume changes"""
        self.volume_callback = callback_func
    
    def cleanup(self):
        """Clean up serial connection"""
        self.running = False
        
        if self.read_thread:
            self.read_thread.join(timeout=2.0)
        
        if self.serial_port:
            self.serial_port.close()
            print("✅ Arduino disconnected")


# Singleton instance
_arduino_interface = None


def get_arduino_interface():
    """Get or create Arduino interface singleton"""
    global _arduino_interface
    if _arduino_interface is None:
        _arduino_interface = ArduinoButtonInterface()
    return _arduino_interface


def cleanup():
    """Clean up Arduino resources"""
    if _arduino_interface:
        _arduino_interface.cleanup()
