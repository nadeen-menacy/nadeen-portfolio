"""
Button input handling for iPod Mood Mirror
Handles GPIO button presses with debouncing and volume knob control
"""

import time
from src import config

# Try to import GPIO libraries, fall back to simulation if unavailable
try:
    if config.HARDWARE_MODE:
        import RPi.GPIO as GPIO
        GPIO_AVAILABLE = True
    else:
        GPIO_AVAILABLE = False
except ImportError:
    GPIO_AVAILABLE = False
    print("⚠️  GPIO not available - running in simulation mode")


class ButtonManager:
    """Manages all button inputs with debouncing"""
    
    def __init__(self):
        self.last_press_time = {}
        self.callbacks = {}
        self.gpio_initialized = False
        
        if GPIO_AVAILABLE:
            self._setup_gpio()
    
    def _setup_gpio(self):
        """Initialize GPIO pins for all buttons"""
        GPIO.setmode(GPIO.BCM)
        
        # Setup mood buttons
        for mood_key, mood_data in config.MOODS.items():
            pin = mood_data['button_pin']
            
            if config.BUTTON_PULL_UP:
                GPIO.setup(pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
            else:
                GPIO.setup(pin, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
            
            # Add event detection
            GPIO.add_event_detect(
                pin,
                GPIO.FALLING if config.BUTTON_PULL_UP else GPIO.RISING,
                callback=lambda channel, mood=mood_key: self._button_callback(mood),
                bouncetime=int(config.BUTTON_DEBOUNCE_TIME * 1000)
            )
            
            self.last_press_time[mood_key] = 0
        
        self.gpio_initialized = True
        print("✅ GPIO initialized for button inputs")
    
    def _button_callback(self, mood_key):
        """Internal callback with additional debouncing"""
        current_time = time.time()
        
        # Additional software debounce
        if current_time - self.last_press_time.get(mood_key, 0) < config.BUTTON_DEBOUNCE_TIME:
            return
        
        self.last_press_time[mood_key] = current_time
        
        # Trigger user callback if registered
        if mood_key in self.callbacks:
            self.callbacks[mood_key](mood_key)
    
    def register_callback(self, mood_key, callback_func):
        """
        Register a callback function for a specific mood button
        
        Args:
            mood_key (str): Mood identifier (e.g., 'jazz', 'chill')
            callback_func: Function to call when button is pressed
        """
        self.callbacks[mood_key] = callback_func
    
    def simulate_button_press(self, mood_key):
        """
        Simulate a button press (for testing without hardware)
        
        Args:
            mood_key (str): Mood to trigger
        """
        print(f"🔘 Simulated button press: {mood_key}")
        self._button_callback(mood_key)
    
    def cleanup(self):
        """Clean up GPIO resources"""
        if GPIO_AVAILABLE and self.gpio_initialized:
            GPIO.cleanup()
            print("✅ GPIO cleaned up")


class VolumeKnob:
    """Handles rotary encoder for volume control"""
    
    def __init__(self):
        self.clk_last_state = None
        self.volume_callback = None
        self.gpio_initialized = False
        
        if GPIO_AVAILABLE:
            self._setup_gpio()
    
    def _setup_gpio(self):
        """Initialize GPIO for rotary encoder"""
        GPIO.setmode(GPIO.BCM)
        
        # Setup rotary encoder pins
        GPIO.setup(config.VOLUME_CLK_PIN, GPIO.IN, pull_up_down=GPIO.PUD_UP)
        GPIO.setup(config.VOLUME_DT_PIN, GPIO.IN, pull_up_down=GPIO.PUD_UP)
        
        # Optional: switch button on rotary encoder
        if config.VOLUME_SW_PIN:
            GPIO.setup(config.VOLUME_SW_PIN, GPIO.IN, pull_up_down=GPIO.PUD_UP)
        
        # Read initial state
        self.clk_last_state = GPIO.input(config.VOLUME_CLK_PIN)
        
        # Add event detection for CLK pin
        GPIO.add_event_detect(
            config.VOLUME_CLK_PIN,
            GPIO.BOTH,
            callback=self._encoder_callback
        )
        
        self.gpio_initialized = True
        print("✅ GPIO initialized for volume knob")
    
    def _encoder_callback(self, channel):
        """Handle rotary encoder rotation"""
        if not GPIO_AVAILABLE:
            return
        
        clk_state = GPIO.input(config.VOLUME_CLK_PIN)
        dt_state = GPIO.input(config.VOLUME_DT_PIN)
        
        # Detect rotation direction
        if clk_state != self.clk_last_state:
            if dt_state != clk_state:
                direction = 1   # Clockwise
            else:
                direction = -1  # Counter-clockwise
            
            # Call volume callback if registered
            if self.volume_callback:
                self.volume_callback(direction)
        
        self.clk_last_state = clk_state
    
    def register_volume_callback(self, callback_func):
        """
        Register callback for volume changes
        
        Args:
            callback_func: Function that takes direction (1 or -1) as parameter
        """
        self.volume_callback = callback_func
    
    def simulate_volume_change(self, direction):
        """
        Simulate volume knob rotation (for testing)
        
        Args:
            direction (int): 1 for increase, -1 for decrease
        """
        print(f"🎚️  Simulated volume change: {'+' if direction > 0 else '-'}")
        if self.volume_callback:
            self.volume_callback(direction)
    
    def cleanup(self):
        """Clean up GPIO resources"""
        if GPIO_AVAILABLE and self.gpio_initialized:
            GPIO.cleanup()
            print("✅ GPIO cleaned up")


# Singleton instances (initialized when needed)
_button_manager = None
_volume_knob = None


def get_button_manager():
    """Get or create ButtonManager singleton"""
    global _button_manager
    if _button_manager is None:
        _button_manager = ButtonManager()
    return _button_manager


def get_volume_knob():
    """Get or create VolumeKnob singleton"""
    global _volume_knob
    if _volume_knob is None:
        _volume_knob = VolumeKnob()
    return _volume_knob


def cleanup_all():
    """Clean up all GPIO resources"""
    if _button_manager:
        _button_manager.cleanup()
    if _volume_knob:
        _volume_knob.cleanup()
