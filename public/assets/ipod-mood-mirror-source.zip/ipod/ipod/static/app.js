// iPod Mood Mirror - Web Interface JavaScript

// WebSocket connection
const socket = io();

// State
let currentMood = null;
let isPlaying = false;

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    initializeControls();
    fetchStatus();
});

// ========== WebSocket Events ==========

socket.on('connect', () => {
    console.log('Connected to server');
    updateConnectionStatus(true);
});

socket.on('disconnect', () => {
    console.log('Disconnected from server');
    updateConnectionStatus(false);
});

socket.on('status_update', (data) => {
    console.log('Status update:', data);
    updateUI(data);
});

// ========== Initialize Controls ==========

function initializeControls() {
    // Mood buttons
    document.querySelectorAll('.mood-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const mood = btn.dataset.mood;
            changeMood(mood);
        });
    });

    // Playback controls
    document.getElementById('prev-btn').addEventListener('click', previousTrack);
    document.getElementById('play-pause-btn').addEventListener('click', togglePlayback);
    document.getElementById('next-btn').addEventListener('click', nextTrack);

    // Volume controls
    document.getElementById('volume-up').addEventListener('click', () => adjustVolume(1));
    document.getElementById('volume-down').addEventListener('click', () => adjustVolume(-1));
    
    const volumeSlider = document.getElementById('volume-slider');
    volumeSlider.addEventListener('input', (e) => {
        setVolume(parseInt(e.target.value));
    });
}

// ========== API Calls ==========

async function fetchStatus() {
    try {
        const response = await fetch('/api/status');
        const data = await response.json();
        updateUI(data);
    } catch (error) {
        console.error('Error fetching status:', error);
    }
}

async function changeMood(mood) {
    try {
        const response = await fetch(`/api/mood/${mood}`, {
            method: 'POST'
        });
        const data = await response.json();
        
        if (data.success) {
            console.log(`Mood changed to: ${mood}`);
        }
    } catch (error) {
        console.error('Error changing mood:', error);
    }
}

async function adjustVolume(direction) {
    try {
        const endpoint = direction > 0 ? '/api/volume/up' : '/api/volume/down';
        const response = await fetch(endpoint, {
            method: 'POST'
        });
        const data = await response.json();
        
        if (data.success) {
            document.getElementById('volume-slider').value = data.volume;
        }
    } catch (error) {
        console.error('Error adjusting volume:', error);
    }
}

async function setVolume(volume) {
    try {
        const response = await fetch('/api/volume', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ volume })
        });
        const data = await response.json();
    } catch (error) {
        console.error('Error setting volume:', error);
    }
}

async function nextTrack() {
    try {
        const response = await fetch('/api/track/next', {
            method: 'POST'
        });
        const data = await response.json();
    } catch (error) {
        console.error('Error skipping track:', error);
    }
}

async function previousTrack() {
    try {
        const response = await fetch('/api/track/previous', {
            method: 'POST'
        });
        const data = await response.json();
    } catch (error) {
        console.error('Error going to previous track:', error);
    }
}

async function togglePlayback() {
    try {
        const response = await fetch('/api/playback/toggle', {
            method: 'POST'
        });
        const data = await response.json();
        
        if (data.success) {
            isPlaying = data.is_playing;
            updatePlayPauseButton(isPlaying);
        }
    } catch (error) {
        console.error('Error toggling playback:', error);
    }
}

// ========== UI Updates ==========

function updateUI(data) {
    // Update mood
    if (data.mood) {
        currentMood = data.mood;
        updateMoodButtons(data.mood);
        document.getElementById('current-mood').textContent = 
            data.mood.charAt(0).toUpperCase() + data.mood.slice(1);
    }

    // Update track
    if (data.track) {
        const trackDisplay = data.total_tracks > 0 
            ? `${data.track} (${data.track_index}/${data.total_tracks})`
            : data.track;
        document.getElementById('current-track').textContent = trackDisplay;
    } else {
        document.getElementById('current-track').textContent = '—';
    }

    // Update volume
    if (data.volume !== undefined) {
        document.getElementById('current-volume').textContent = `${data.volume}%`;
        document.getElementById('volume-slider').value = data.volume;
    }

    // Update playback status
    if (data.is_playing !== undefined) {
        isPlaying = data.is_playing;
        updatePlayPauseButton(data.is_playing);
    }
}

function updateMoodButtons(activeMood) {
    document.querySelectorAll('.mood-btn').forEach(btn => {
        if (btn.dataset.mood === activeMood) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });
}

function updatePlayPauseButton(playing) {
    const icon = document.getElementById('play-pause-icon');
    icon.textContent = playing ? '⏸' : '▶';
}

function updateConnectionStatus(connected) {
    const indicator = document.getElementById('connection-indicator');
    const text = document.getElementById('connection-text');
    
    if (connected) {
        indicator.classList.add('connected');
        indicator.classList.remove('disconnected');
        text.textContent = 'Connected';
    } else {
        indicator.classList.add('disconnected');
        indicator.classList.remove('connected');
        text.textContent = 'Disconnected';
    }
}

// ========== Keyboard Shortcuts ==========

document.addEventListener('keydown', (e) => {
    // Space: Play/Pause
    if (e.code === 'Space') {
        e.preventDefault();
        togglePlayback();
    }
    
    // Arrow keys: Volume and track control
    if (e.code === 'ArrowUp') {
        e.preventDefault();
        adjustVolume(1);
    }
    if (e.code === 'ArrowDown') {
        e.preventDefault();
        adjustVolume(-1);
    }
    if (e.code === 'ArrowRight') {
        e.preventDefault();
        nextTrack();
    }
    if (e.code === 'ArrowLeft') {
        e.preventDefault();
        previousTrack();
    }
    
    // Number keys: Mood selection
    if (e.code === 'Digit1') changeMood('jazz');
    if (e.code === 'Digit2') changeMood('chill');
    if (e.code === 'Digit3') changeMood('happy');
    if (e.code === 'Digit4') changeMood('arabic');
});
