"""
Web Server for iPod Mood Mirror
Provides REST API and WebSocket interface for remote control
"""

from flask import Flask, render_template, jsonify, request
from flask_socketio import SocketIO, emit
import threading
import time
from src import config
from src.audio import get_audio_player
from src.led_control import get_led_controller
from src.buttons import get_button_manager, get_volume_knob

app = Flask(__name__)
app.config['SECRET_KEY'] = 'ipod-mood-mirror-secret'
socketio = SocketIO(app, cors_allowed_origins="*")

# Global state
current_state = {
    'current_mood': config.STARTUP_MOOD,
    'volume': config.DEFAULT_VOLUME,
    'is_playing': False,
    'current_track': None
}


class WebInterface:
    """Web interface controller"""
    
    def __init__(self, audio_player, led_controller):
        self.audio_player = audio_player
        self.led_controller = led_controller
        self.update_thread = None
        self.running = False
    
    def start(self):
        """Start the web interface"""
        self.running = True
        self.update_thread = threading.Thread(target=self._status_update_loop)
        self.update_thread.daemon = True
        self.update_thread.start()
    
    def stop(self):
        """Stop the web interface"""
        self.running = False
        if self.update_thread:
            self.update_thread.join(timeout=2.0)
    
    def _status_update_loop(self):
        """Periodically broadcast status updates via WebSocket"""
        while self.running:
            try:
                status = self.get_status()
                socketio.emit('status_update', status, namespace='/')
            except Exception as e:
                print(f"⚠️  Status update error: {e}")
            time.sleep(2.0)  # Update every 2 seconds
    
    def get_status(self):
        """Get current system status"""
        track_info = self.audio_player.get_current_track_info()
        
        return {
            'mood': current_state['current_mood'],
            'volume': int(self.audio_player.volume * 100),
            'is_playing': self.audio_player.is_playing,
            'track': track_info['filename'] if track_info else None,
            'track_index': track_info['index'] if track_info else 0,
            'total_tracks': track_info['total'] if track_info else 0,
            'current_color': self.led_controller.current_color
        }
    
    def change_mood(self, mood_key):
        """Change to a different mood"""
        if mood_key not in config.MOODS:
            return {'success': False, 'error': 'Invalid mood'}
        
        mood_data = config.MOODS[mood_key]
        
        # Update LED color
        self.led_controller.set_color(mood_data['color'], fade=True)
        
        # Load and play playlist
        if self.audio_player.load_playlist(mood_key):
            self.audio_player.play()
            current_state['current_mood'] = mood_key
            current_state['is_playing'] = True
            
            print(f"🌐 Web: Changed mood to {mood_data['name']}")
            return {'success': True, 'mood': mood_key}
        else:
            return {'success': False, 'error': 'Playlist not found'}
    
    def adjust_volume(self, direction):
        """Adjust volume by direction"""
        self.audio_player.adjust_volume(direction)
        current_state['volume'] = self.audio_player.volume
        return {'success': True, 'volume': int(self.audio_player.volume * 100)}
    
    def set_volume(self, volume):
        """Set volume to specific level (0-100)"""
        volume_float = max(0.0, min(1.0, volume / 100.0))
        self.audio_player.set_volume(volume_float)
        current_state['volume'] = volume_float
        return {'success': True, 'volume': int(self.audio_player.volume * 100)}
    
    def next_track(self):
        """Skip to next track"""
        self.audio_player.next_track()
        return {'success': True}
    
    def previous_track(self):
        """Go to previous track"""
        self.audio_player.previous_track()
        return {'success': True}
    
    def toggle_playback(self):
        """Pause or resume playback"""
        if self.audio_player.is_playing:
            self.audio_player.pause()
        else:
            self.audio_player.unpause()
        return {'success': True, 'is_playing': self.audio_player.is_playing}


# Global web interface instance
web_interface = None


def get_web_interface(audio_player=None, led_controller=None):
    """Get or create web interface singleton"""
    global web_interface
    if web_interface is None and audio_player and led_controller:
        web_interface = WebInterface(audio_player, led_controller)
    return web_interface


# ========== REST API Routes ==========

@app.route('/')
def index():
    """Serve the main web interface"""
    return render_template('index.html', moods=config.MOODS)


@app.route('/api/status')
def api_status():
    """Get current system status"""
    if web_interface:
        return jsonify(web_interface.get_status())
    return jsonify({'error': 'System not initialized'}), 500


@app.route('/api/mood/<mood_key>', methods=['POST'])
def api_change_mood(mood_key):
    """Change mood"""
    if web_interface:
        result = web_interface.change_mood(mood_key)
        return jsonify(result)
    return jsonify({'error': 'System not initialized'}), 500


@app.route('/api/volume', methods=['POST'])
def api_set_volume():
    """Set volume level"""
    data = request.get_json()
    volume = data.get('volume', 50)
    
    if web_interface:
        result = web_interface.set_volume(volume)
        return jsonify(result)
    return jsonify({'error': 'System not initialized'}), 500


@app.route('/api/volume/up', methods=['POST'])
def api_volume_up():
    """Increase volume"""
    if web_interface:
        result = web_interface.adjust_volume(1)
        return jsonify(result)
    return jsonify({'error': 'System not initialized'}), 500


@app.route('/api/volume/down', methods=['POST'])
def api_volume_down():
    """Decrease volume"""
    if web_interface:
        result = web_interface.adjust_volume(-1)
        return jsonify(result)
    return jsonify({'error': 'System not initialized'}), 500


@app.route('/api/track/next', methods=['POST'])
def api_next_track():
    """Skip to next track"""
    if web_interface:
        result = web_interface.next_track()
        return jsonify(result)
    return jsonify({'error': 'System not initialized'}), 500


@app.route('/api/track/previous', methods=['POST'])
def api_previous_track():
    """Go to previous track"""
    if web_interface:
        result = web_interface.previous_track()
        return jsonify(result)
    return jsonify({'error': 'System not initialized'}), 500


@app.route('/api/playback/toggle', methods=['POST'])
def api_toggle_playback():
    """Pause/resume playback"""
    if web_interface:
        result = web_interface.toggle_playback()
        return jsonify(result)
    return jsonify({'error': 'System not initialized'}), 500


# ========== WebSocket Events ==========

@socketio.on('connect')
def handle_connect():
    """Handle client connection"""
    print('🌐 Web client connected')
    if web_interface:
        emit('status_update', web_interface.get_status())


@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection"""
    print('🌐 Web client disconnected')


@socketio.on('change_mood')
def handle_change_mood(data):
    """Handle mood change from client"""
    mood_key = data.get('mood')
    if web_interface and mood_key:
        result = web_interface.change_mood(mood_key)
        emit('status_update', web_interface.get_status(), broadcast=True)


@socketio.on('adjust_volume')
def handle_adjust_volume(data):
    """Handle volume adjustment from client"""
    direction = data.get('direction', 0)
    if web_interface:
        web_interface.adjust_volume(direction)
        emit('status_update', web_interface.get_status(), broadcast=True)


def run_web_server(audio_player, led_controller, host='0.0.0.0', port=5000):
    """
    Start the web server
    
    Args:
        audio_player: AudioPlayer instance
        led_controller: LEDController instance
        host: Host address (default: 0.0.0.0 for all interfaces)
        port: Port number (default: 5000)
    """
    global web_interface
    
    # Initialize web interface
    web_interface = get_web_interface(audio_player, led_controller)
    web_interface.start()
    
    print(f"\n🌐 Web server starting on http://{host}:{port}")
    print(f"📱 Access from any device on your network")
    print(f"💻 Local: http://localhost:{port}\n")
    
    # Run server
    socketio.run(app, host=host, port=port, debug=False, allow_unsafe_werkzeug=True)


if __name__ == '__main__':
    print("⚠️  Run web server through main.py, not directly")
