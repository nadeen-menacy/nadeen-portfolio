# iPod Mood Mirror - Setup Checklist

**System: Laptop-Based Installation**

Use this checklist to track your build progress.

---

## Phase 1: Development & Testing

- [ ] Have laptop ready (Windows/Mac/Linux)
- [ ] Install Python 3.7+ on laptop
- [ ] Install pygame: `pip install pygame Flask flask-socketio pyserial`
- [ ] Clone/download project files
- [ ] Set `HARDWARE_MODE = False` in `config.py`
- [ ] Add at least one MP3 file to each mood folder
- [ ] Run `python main.py` successfully
- [ ] Open web interface at `http://localhost:5000`
- [ ] Test all web controls (mood buttons, volume, playback)
- [ ] Test keyboard controls (1-4, arrows)
- [ ] Verify LED color changes (console output)
- [ ] Verify audio playback
- [ ] Test from phone/tablet on same WiFi

---

## Phase 2: Physical Construction

### Frame Construction
- [ ] Purchase MDF/Plywood (12-15mm thick)
- [ ] Cut frame to 110cm x 40cm iPod shape
- [ ] Create 10-20cm depth for electronics
- [ ] Route 1cm deep channel for LED strip (optional)
- [ ] Drill 4 button holes (30mm diameter) - if using physical buttons
- [ ] Drill center hole for volume knob - optional
- [ ] Cut speaker grille opening (lower left back)
- [ ] Create access door for laptop/wiring (lower right back)
- [ ] Sand and finish frame
- [ ] Purchase mirror cut to size (108cm x 38cm)

### Component Procurement (All Optional)
- [ ] Arduino Uno (~$25) - Only if you want physical buttons
- [ ] 4× momentary push buttons (30mm) - Only with Arduino
- [ ] Rotary encoder (KY-040) - Only with Arduino
- [ ] Jumper wires (M-F, M-M) - Only with Arduino
- [ ] USB A-to-B cable for Arduino
- [ ] WS2812B LED strip (3-4 meters, 60 LEDs/m) - Optional
- [ ] USB LED controller or driver - If using LEDs
- [ ] Desktop speaker with AUX input
- [ ] 3.5mm audio cable or Bluetooth
- [ ] Extension cord for laptop power
- [ ] USB hub (if needed for multiple devices)
- [ ] Mounting hardware (screws, standoffs)

---

## Phase 3: Electronics Assembly

### Laptop Setup
- [ ] Ensure laptop has enough USB ports (or get USB hub)
- [ ] Install all Python dependencies
- [ ] Configure audio output to speaker
- [ ] Test audio: Play a test file
- [ ] Note laptop's IP address for network access

### Arduino Button Wiring (Optional)
- [ ] Upload `arduino_code/ipod_buttons.ino` to Arduino
- [ ] Connect Jazz button to Pin 2 + GND
- [ ] Connect Chill button to Pin 3 + GND
- [ ] Connect Happy button to Pin 4 + GND
- [ ] Connect Arabic button to Pin 5 + GND
- [ ] Test each button with Arduino Serial Monitor
- [ ] Mount buttons in frame holes

### Volume Knob Wiring (Optional)
- [ ] Connect encoder CLK to Arduino Pin 6
- [ ] Connect encoder DT to Arduino Pin 7
- [ ] Connect encoder GND to Arduino GND
- [ ] Connect encoder VCC to Arduino 5V
- [ ] Test encoder rotation

### LED Strip Setup (Optional)
- [ ] Get USB LED controller compatible with WS2812B
- [ ] Connect LED data to controller
- [ ] Connect LED power (may need separate USB power)
- [ ] Test with minimal LED count first
- [ ] Mount LED strip in frame channel

### Audio Wiring
- [ ] Connect speaker to laptop (3.5mm jack or Bluetooth)
- [ ] Test audio output
- [ ] Adjust volume with laptop/speaker controls

---

## Phase 4: Software Installation

- [ ] Ensure project files are on laptop
- [ ] Install requirements: `pip install -r requirements.txt`
- [ ] Set `HARDWARE_MODE = False` in `config.py`
- [ ] If using Arduino: Connect Arduino via USB
- [ ] Copy MP3 files to mood folders
- [ ] Test run: `python main.py`
- [ ] Verify Arduino auto-detection (if connected)
- [ ] Test web interface: `http://localhost:5000`
- [ ] Test from phone on same WiFi network

---

## Phase 5: Integration & Testing

### Component Tests
- [ ] Test web interface from laptop browser
- [ ] Test web interface from phone/tablet
- [ ] Test each mood button (web or physical)
- [ ] Verify music starts on button press
- [ ] Check music changes between moods
- [ ] Test volume controls (web slider)
- [ ] Test track skip buttons (web)
- [ ] If using Arduino: Test physical buttons
- [ ] If using Arduino: Test physical volume knob
- [ ] Verify shuffle functionality
- [ ] Test continuous playback loop

### Real-Time Sync Tests (if using Arduino)
- [ ] Press physical button → Web UI updates
- [ ] Click web button → Same effect as physical
- [ ] Turn physical knob → Web volume changes
- [ ] Multiple devices can view status

### Full System Tests
- [ ] Run for 1 hour continuously
- [ ] Test all mood transitions
- [ ] Verify LED color changes (if using LEDs)
- [ ] Check for audio glitches
- [ ] Monitor laptop temperature/battery
- [ ] Test clean shutdown (Ctrl+C)

---

## Phase 6: Final Assembly

- [ ] Mount LED strip in routed channel (if using)
- [ ] Install mirror in frame recess
- [ ] Create laptop mounting shelf/holder inside frame
- [ ] Attach speaker behind grille
- [ ] Organize all wiring (cable ties)
- [ ] Route laptop power cable cleanly
- [ ] Route USB cables for Arduino/LEDs (if using)
- [ ] Test all functions after assembly
- [ ] Add diffuser over LEDs (optional)
- [ ] Ensure laptop is accessible for updates
- [ ] Create cable management solution
- [ ] Add ventilation for laptop cooling

---

## Phase 7: Installation & Deployment

- [ ] Choose wall location near power outlet
- [ ] Install wall mounting brackets
- [ ] Ensure WiFi signal strength is good
- [ ] Mount mirror securely
- [ ] Connect laptop power (hide cable)
- [ ] Connect speaker power (if needed)
- [ ] Test from fresh laptop boot
- [ ] Set laptop to not sleep when plugged in
- [ ] Create desktop shortcut to start app
- [ ] Test web access from all your devices
- [ ] Create music backup on laptop
- [ ] Document laptop IP address
- [ ] Add music to all mood folders

---

## Optional Enhancements

- [ ] Set up auto-start when laptop boots
- [ ] Add laptop cooling fan to frame
- [ ] Install remote power switch
- [ ] Add USB charging ports to frame
- [ ] Create custom button icons/labels
- [ ] Add battery backup (UPS) for laptop
- [ ] Set up remote desktop access
- [ ] Create music upload web interface
- [ ] Add visualization to web interface
- [ ] Mount tablet as permanent display

---

## Maintenance Checklist

### Weekly
- [ ] Check laptop for software updates
- [ ] Add new music files
- [ ] Verify all functions work
- [ ] Clean laptop vents/fans

### Monthly
- [ ] Clean mirror surface
- [ ] Check USB connections
- [ ] Verify button responsiveness (if using)
- [ ] Backup music library
- [ ] Clear laptop temp files
- [ ] Check speaker connections

### As Needed
- [ ] Replace worn buttons (if using)
- [ ] Update Python packages
- [ ] Adjust LED brightness (if using)
- [ ] Reorganize playlists
- [ ] Clean speaker grille
- [ ] Restart laptop if sluggish

---

## Troubleshooting Reference

| Issue | Check |
|-------|-------|
| Arduino not detected | USB cable, Arduino drivers, Device Manager COM port |
| No Audio | Speaker connection, laptop volume, audio cable |
| Web interface won't load | Port 5000 not blocked, firewall settings |
| Music Won't Play | MP3 files exist, pygame installed, file paths |
| Can't access from phone | Same WiFi network, laptop firewall, correct IP |
| Laptop overheating | Add cooling fan, ensure ventilation |
| System sluggish | Close other apps, restart laptop, check RAM usage |

---

## Notes & Customizations

Use this space to track your specific settings:

**My Laptop:**
- Model: ___
- OS: ___
- IP Address: ___
- WiFi Network: ___

**My Arduino Pins (if using):**
- Jazz: Pin 2
- Chill: Pin 3
- Happy: Pin 4
- Arabic: Pin 5
- Volume CLK: Pin 6
- Volume DT: Pin 7

**My Music:**
- Jazz tracks: ___
- Chill tracks: ___
- Happy tracks: ___
- Arabic tracks: ___

**Access URLs:**
- Laptop: http://localhost:5000
- Phone/Tablet: http://___:5000

---

**Last Updated:** [Add date after final testing]
**Status:** [Not Started | In Progress | Complete]
