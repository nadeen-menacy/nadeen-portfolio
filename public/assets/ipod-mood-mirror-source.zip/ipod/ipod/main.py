#!/usr/bin/env python3
"""
iPod Mood Mirror - Main Application
Interactive art installation with mood-based music and lighting
"""

import pygame
import sys
import signal
import time
import threading
from src import config
from src.buttons import get_button_manager, get_volume_knob, cleanup_all as cleanup_buttons
from src.led_control import get_led_controller, cleanup as cleanup_leds
from src.audio import get_audio_player, cleanup as cleanup_audio
from src.web_server import run_web_server
from src.arduino_buttons import get_arduino_interface, cleanup as cleanup_arduino


class iPodMoodMirror:
    """Main application controller for iPod Mood Mirror"""
    
    def __init__(self, enable_web=True, enable_arduino=True):
        print("\n🎵 iPod Mood Mirror Starting...\n")
        
        # Initialize pygame for event handling
        pygame.init()
        
        # Initialize all components
        self.button_manager = get_button_manager()
        self.volume_knob = get_volume_knob()
        self.led_controller = get_led_controller()
        self.audio_player = get_audio_player()
        
        # Initialize Arduino interface (optional)
        self.arduino_interface = None
        if enable_arduino:
            self.arduino_interface = get_arduino_interface()
            if self.arduino_interface.serial_port:
                self._register_arduino_callbacks()
                self.arduino_interface.start()
        
        # Register callbacks
        self._register_button_callbacks()
        self._register_volume_callback()
        
        # Set up signal handlers for clean shutdown
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
        
        self.running = True
        self.enable_web = enable_web
        self.web_thread = None
        
        print("✅ All systems initialized\n")
    
    def _register_button_callbacks(self):
        """Register callbacks for all mood buttons"""
        for mood_key in config.MOODS.keys():
            self.button_manager.register_callback(mood_key, self._mood_button_pressed)
    
    def _register_volume_callback(self):
        """Register callback for volume knob"""
        self.volume_knob.register_volume_callback(self._volume_changed)
    
    def _register_arduino_callbacks(self):
        """Register callbacks for Arduino buttons"""
        if self.arduino_interface:
            for mood_key in config.MOODS.keys():
                self.arduino_interface.register_callback(mood_key, self._mood_button_pressed)
            self.arduino_interface.register_volume_callback(self._volume_changed)
    
    def _mood_button_pressed(self, mood_key):
        """
        Handle mood button press
        
        Args:
            mood_key (str): The mood that was selected
        """
        mood_data = config.MOODS[mood_key]
        mood_name = mood_data['name']
        mood_color = mood_data['color']
        
        print(f"\n🎭 Mood Selected: {mood_name}")
        
        # Fade LEDs to mood color
        self.led_controller.set_color(mood_color, fade=True)
        
        # Load and play mood playlist
        if self.audio_player.load_playlist(mood_key):
            self.audio_player.play()
        else:
            print(f"⚠️  Could not load playlist for {mood_name}")
    
    def _volume_changed(self, direction):
        """
        Handle volume knob rotation
        
        Args:
            direction (int): 1 for increase, -1 for decrease
        """
        self.audio_player.adjust_volume(direction)
    
    def _signal_handler(self, sig, frame):
        """Handle shutdown signals"""
        print("\n\n🛑 Shutdown signal received")
        self.running = False
    
    def start_with_default_mood(self):
        """Initialize system with default mood"""
        print(f"🎬 Starting with default mood: {config.STARTUP_MOOD}\n")
        self._mood_button_pressed(config.STARTUP_MOOD)
    
    def run(self):
        """Main event loop"""
        print("🔄 Main loop started\n")
        print("Press a mood button to change the vibe!")
        print("Turn the volume knob to adjust volume.")
        
        # Start web server in background thread if enabled
        if self.enable_web:
            self.web_thread = threading.Thread(
                target=run_web_server,
                args=(self.audio_player, self.led_controller),
                kwargs={'host': '0.0.0.0', 'port': 5000}
            )
            self.web_thread.daemon = True
            self.web_thread.start()
            print("")
        
        print("Press Ctrl+C to exit.\n")
        
        # Start with default mood
        self.start_with_default_mood()
        
        # Main event loop
        clock = pygame.time.Clock()
        
        while self.running:
            # Process pygame events
            for event in pygame.event.get():
                # Handle track end event
                if event.type == pygame.USEREVENT + 1:
                    self.audio_player.handle_track_end()
                
                # Handle quit event (for testing)
                elif event.type == pygame.QUIT:
                    self.running = False
            
            # Check for keyboard input (for testing without hardware)
            if config.SIMULATE_HARDWARE:
                keys = pygame.key.get_pressed()
                
                # Mood buttons: 1, 2, 3, 4
                if keys[pygame.K_1]:
                    self.button_manager.simulate_button_press('jazz')
                    time.sleep(0.3)
                elif keys[pygame.K_2]:
                    self.button_manager.simulate_button_press('chill')
                    time.sleep(0.3)
                elif keys[pygame.K_3]:
                    self.button_manager.simulate_button_press('happy')
                    time.sleep(0.3)
                elif keys[pygame.K_4]:
                    self.button_manager.simulate_button_press('arabic')
                    time.sleep(0.3)
                
                # Volume control: Up/Down arrows
                elif keys[pygame.K_UP]:
                    self.volume_knob.simulate_volume_change(1)
                    time.sleep(0.2)
                elif keys[pygame.K_DOWN]:
                    self.volume_knob.simulate_volume_change(-1)
                    time.sleep(0.2)
                
                # Track control: Left/Right arrows
                elif keys[pygame.K_RIGHT]:
                    self.audio_player.next_track()
                    time.sleep(0.3)
                elif keys[pygame.K_LEFT]:
                    self.audio_player.previous_track()
                    time.sleep(0.3)
            
            # Limit loop rate
            clock.tick(30)
        
        print("\n🛑 Main loop stopped")
    
    def cleanup(self):
        """Clean up all resources"""
        print("\n🧹 Cleaning up...")
        
        cleanup_audio()
        cleanup_leds()
        cleanup_buttons()
        cleanup_arduino()
        
        pygame.quit()
        
        print("✅ Cleanup complete")
        print("\n👋 Goodbye!\n")


def main():
    """Application entry point"""
    app = None
    
    try:
        # Check command line arguments
        enable_web = '--no-web' not in sys.argv
        
        # Create and run the application
        app = iPodMoodMirror(enable_web=enable_web)
        app.run()
        
    except KeyboardInterrupt:
        print("\n\n⚠️  Interrupted by user")
        
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        import traceback
        traceback.print_exc()
        
    finally:
        # Always clean up
        if app:
            app.cleanup()
        sys.exit(0)


if __name__ == "__main__":
    main()
