# 🎵 iPod Mood Mirror

An interactive art installation combining a large iPod-shaped mirror with mood-based music and ambient lighting.

---

## Overview

The iPod Mood Mirror is a 110cm x 40cm physical installation that responds to button presses by:
- Playing mood-specific playlists (Jazz, Chill R&B, Happy, Arabic)
- Displaying corresponding ambient LED colors (Orange, Red, Yellow, Purple)
- Allowing volume control via physical knob or web interface

**Your laptop is the brain** - it runs all the software, hosts the web interface, and plays the music. Optional Arduino buttons connect via USB for physical interaction.

**No screens. Just buttons, light, sound, and mirrors.**

---

## Quick Start

### For Testing (No Hardware)

1. **Install Dependencies**
   ```bash
   pip install pygame Flask flask-socketio pyserial
   ```

2. **Add Music Files**
   - Place MP3s in the mood folders:
     - `music/jazz/`
     - `music/chill/`
     - `music/happy/`
     - `music/arabic/`

3. **Set Development Mode**
   - Open `config.py`
   - Set `HARDWARE_MODE = False`

4. **Run Application**
   ```bash
   python main.py
   ```

5. **Access Web Interface**
   - Open browser to `http://localhost:5000`
   - Control the system from any device on your network

6. **Use Keyboard Controls (in console)**
   - `1`, `2`, `3`, `4` - Select moods
   - `↑` / `↓` - Adjust volume
   - `←` / `→` - Skip tracks
   - `Ctrl+C` - Exit

---

### With Arduino Physical Buttons

1. **Upload Arduino Code**
   - Open `arduino_code/ipod_buttons.ino` in Arduino IDE
   - Upload to your Arduino Uno

2. **Wire Buttons to Arduino**
   ```
   Button 1 (Jazz)   → Pin 2 → GND
   Button 2 (Chill)  → Pin 3 → GND  
   Button 3 (Happy)  → Pin 4 → GND
   Button 4 (Arabic) → Pin 5 → GND
   Encoder CLK       → Pin 6
   Encoder DT        → Pin 7
   ```

3. **Connect Arduino to Laptop via USB**

4. **Run Application**
   ```bash
   python main.py
   ```
   - Auto-detects Arduino
   - Physical buttons + web interface both work!
   - Press physical button → Web UI updates
   - Click web button → Same effect

---

### For Hardware Installation

See **[HARDWARE_GUIDE.md](HARDWARE_GUIDE.md)** for complete wiring diagrams, component lists, and installation instructions.

---

## Project Structure

```
ipod/
├── main.py              # Main application entry point
├── config.py            # Mood mappings, GPIO pins, settings
├── buttons.py           # Button input & volume knob handling
├── led_control.py       # RGB LED strip control with fading
├── audio.py             # Playlist management & MP3 playback
├── requirements.txt     # Python dependencies
├── HARDWARE_GUIDE.md    # Complete hardware documentation
└── music/
    ├── jazz/           # Jazz mood MP3s
    ├── chill/          # Chill R&B MP3s
    ├── happy/          # Happy mood MP3s
    └── arabic/         # Arabic mood MP3s
```

---

## Configuration

### Mood Settings (`config.py`)

Each mood has:
- **Name** - Display name
- **Color** - RGB values for LED strip
- **Button Pin** - GPIO pin number
- **Playlist Folder** - Music directory

Example:
```python
'jazz': {
    'name': 'Jazz',
    'color': (255, 140, 0),      # Orange
    'button_pin': 17,
    'playlist_folder': 'music/jazz'
}
```

### Hardware Pins

- **Mood Buttons:** GPIO 17, 27, 22, 23
- **Volume Knob:** GPIO 5 (CLK), 6 (DT), 13 (SW)
- **LED Strip:** GPIO 18 (PWM)

**Adjust in `config.py` to match your wiring.**

---

## Features

### ✅ Implemented
- Four mood buttons with debouncing
- Smooth LED color fading transitions
- MP3 playlist playback with shuffle
- Volume control via rotary encoder
- Continuous playback mode
- Auto-advance to next track
- Clean shutdown handling
- Development mode (keyboard simulation)
- **🌐 Web interface for remote control**
- **📱 Real-time status updates via WebSocket**
- **💻 Control from any device on your network**

### 🎯 Hardware Requirements
- **Laptop** (Windows/Mac/Linux) - Your brain and power source
- **Arduino Uno** (~$25) - Optional, for physical buttons
- **WS2812B LED strip** - Optional, for ambient lighting
- **4 push buttons** (~$5) - Optional, if using Arduino
- **Rotary encoder** (~$3) - Optional, if using Arduino
- **Desktop speaker** - Any speaker with AUX/Bluetooth
- **USB cables** - For Arduino and LED connections

---

## Usage

### Web Interface

The web interface provides full remote control:

1. **Start the system:**
   ```bash
   python main.py
   ```

2. **Access from any device:**
   - Local: `http://localhost:5000`
   - Network: `http://[your-laptop-ip]:5000`
   - Phone/Tablet: Same URL on your WiFi network

3. **Web Features:**
   - Select moods with large touch-friendly buttons
   - View current track and status
   - Adjust volume with slider or +/- buttons
   - Control playback (play/pause, next/previous)
   - Real-time updates when physical buttons are pressed
   - Keyboard shortcuts (1-4 for moods, arrows for control)

4. **To disable web interface:**
   ```bash
   python main.py --no-web
   ```

### Physical Controls (Optional)

If you add Arduino buttons:
- Connect Arduino via USB to laptop
- Press physical buttons → Web UI updates
- Click web buttons → Physical feedback
- Both control the same system in real-time

### Adding Music
1. Place MP3 files in mood folders (`music/jazz/`, etc.)
2. Restart application
3. Files are automatically detected and shuffled

### Customizing Moods
Edit `config.py` to:
- Change LED colors
- Adjust GPIO pins
- Modify fade duration
- Set default volume
- Change startup mood

### Extending the System
The modular design allows easy additions:
- Add new moods in `config.py`
- Wire additional buttons
- Change LED animation styles in `led_control.py`
- Modify shuffle/playback behavior in `audio.py`

---

## Technical Details

### Software
- **Python 3.7+**
- **pygame** - Audio playback
- **Flask** - Web server
- **flask-socketio** - Real-time updates
- **pyserial** - Arduino USB communication (optional)

### Hardware
- **Computing:** Your laptop (Windows/Mac/Linux)
- **LEDs:** WS2812B addressable RGB strip (optional)
- **Audio:** Laptop → 3.5mm/Bluetooth → External speaker
- **Buttons:** Arduino Uno via USB (optional)
- **Power:** Laptop powers everything

---

## Troubleshooting

### No Music Playing
- Check MP3 files exist in mood folders
- Verify file permissions
- Test speaker connection

### LEDs Not Working
- Ensure running as root: `sudo python3 main.py`
- Check GPIO 18 wiring and level shifter
- Verify 5V power supply capacity

### Buttons Not Responding
- Test GPIO connections with multimeter
- Verify BCM pin mode in code
- Check pull-up resistor configuration

**See [HARDWARE_GUIDE.md](HARDWARE_GUIDE.md) for detailed troubleshooting.**

---

## Development

### Running Tests
```bash
# Set simulation mode
# In config.py: HARDWARE_MODE = False

python main.py
```

### Debugging
- Console output shows all events
- LED color changes are logged
- Track changes are displayed
- Button presses are confirmed

---

## Safety

⚠️ **Important:**
- Use proper wire gauge for LED power
- Add 1000µF capacitor to LED strip
- Connect all grounds together
- Never exceed power supply ratings
- Ensure adequate ventilation

---

## License

This project is open source. Feel free to modify and adapt for your own installations.

---

## Credits

Created for interactive art and music visualization.

**Built with:** Raspberry Pi, Python, pygame, WS2812B LEDs

---

## Next Steps

1. **Review** - Read [HARDWARE_GUIDE.md](HARDWARE_GUIDE.md)
2. **Test** - Run in simulation mode
3. **Build** - Wire up components
4. **Deploy** - Install in mirror frame
5. **Enjoy** - Press buttons and vibe! 🎶
