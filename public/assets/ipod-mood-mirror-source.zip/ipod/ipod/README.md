# iPod Mood Mirror

Interactive art installation with mood-based music and lighting.

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Add music to folders
# music/jazz/, music/chill/, music/happy/, music/arabic/

# Run the application
python main.py

# Access web interface
# http://localhost:5000
```

## Documentation

See [docs/README.md](docs/README.md) for complete documentation.

## Project Structure

```
ipod/
├── main.py              # Application entry point
├── requirements.txt     # Python dependencies
├── src/                 # Source code
│   ├── config.py        # Configuration settings
│   ├── audio.py         # Music playback
│   ├── buttons.py       # GPIO button handling
│   ├── led_control.py   # LED strip control
│   ├── web_server.py    # Web interface
│   └── arduino_buttons.py  # Arduino USB interface
├── arduino_code/        # Arduino firmware
│   └── ipod_buttons.ino
├── templates/           # Web templates
│   └── index.html
├── static/              # Web assets
│   ├── style.css
│   └── app.js
├── music/               # Music library
│   ├── jazz/
│   ├── chill/
│   ├── happy/
│   └── arabic/
└── docs/                # Documentation
    ├── README.md
    ├── ARDUINO_SETUP.txt
    ├── HARDWARE_GUIDE.md
    ├── SETUP_CHECKLIST.md
    └── WEB_GUIDE.md
```

## Features

- **Web Interface** - Control from any device on your network
- **Physical Buttons** - Optional Arduino buttons via USB
- **Real-time Sync** - Web and buttons work together
- **Minimal Design** - Clean black & white aesthetic
- **Laptop-Based** - No Raspberry Pi needed

Built with Python, Flask, and pygame.
