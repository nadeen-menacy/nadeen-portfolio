"""
LED control for iPod Mood Mirror
Handles RGB LED strip with smooth color fading transitions
"""

import time
import threading
from src import config

# Try to import LED libraries
try:
    if config.HARDWARE_MODE:
        from rpi_ws281x import PixelStrip, Color
        WS281X_AVAILABLE = True
    else:
        WS281X_AVAILABLE = False
except ImportError:
    WS281X_AVAILABLE = False
    print("⚠️  WS281x library not available - LED simulation mode")


class LEDController:
    """Controls RGB LED strip with smooth fading effects"""
    
    def __init__(self):
        self.current_color = (0, 0, 0)  # Start with LEDs off
        self.target_color = (0, 0, 0)
        self.is_fading = False
        self.fade_thread = None
        self.strip = None
        self.running = True
        
        if WS281X_AVAILABLE:
            self._setup_led_strip()
        else:
            print("🔆 LED Controller initialized in simulation mode")
    
    def _setup_led_strip(self):
        """Initialize the LED strip hardware"""
        # LED strip configuration:
        # - LED_PIN: GPIO pin connected to the pixels (must support PWM)
        # - LED_COUNT: Number of LED pixels
        # - LED_FREQ_HZ: LED signal frequency in hertz (usually 800khz)
        # - LED_DMA: DMA channel to use for generating signal (try 10)
        # - LED_BRIGHTNESS: Brightness level (0-255)
        # - LED_INVERT: True to invert the signal (when using NPN transistor level shift)
        
        LED_FREQ_HZ = 800000  # LED signal frequency in Hz (800kHz)
        LED_DMA = 10          # DMA channel to use
        LED_BRIGHTNESS_INT = int(config.LED_BRIGHTNESS * 255)
        LED_INVERT = False    # Set True if using inverting level shifter
        LED_CHANNEL = 0       # PWM channel
        
        self.strip = PixelStrip(
            config.LED_COUNT,
            config.LED_PIN,
            LED_FREQ_HZ,
            LED_DMA,
            LED_INVERT,
            LED_BRIGHTNESS_INT,
            LED_CHANNEL
        )
        
        self.strip.begin()
        print(f"✅ LED strip initialized ({config.LED_COUNT} LEDs on GPIO {config.LED_PIN})")
    
    def set_color(self, color, fade=True):
        """
        Set LED strip to a specific color
        
        Args:
            color (tuple): RGB color tuple (r, g, b) with values 0-255
            fade (bool): Whether to fade to the new color or change instantly
        """
        if fade:
            self._fade_to_color(color)
        else:
            self._set_immediate_color(color)
    
    def _set_immediate_color(self, color):
        """Set color immediately without fading"""
        self.current_color = color
        self.target_color = color
        
        if WS281X_AVAILABLE and self.strip:
            r, g, b = color
            for i in range(self.strip.numPixels()):
                self.strip.setPixelColor(i, Color(r, g, b))
            self.strip.show()
        else:
            print(f"🎨 LED color set to RGB{color}")
    
    def _fade_to_color(self, target_color):
        """
        Smoothly fade from current color to target color
        
        Args:
            target_color (tuple): Target RGB color
        """
        self.target_color = target_color
        
        # Stop any existing fade
        if self.fade_thread and self.fade_thread.is_alive():
            self.is_fading = False
            self.fade_thread.join()
        
        # Start new fade thread
        self.is_fading = True
        self.fade_thread = threading.Thread(target=self._fade_worker)
        self.fade_thread.daemon = True
        self.fade_thread.start()
    
    def _fade_worker(self):
        """Worker thread that performs the color fade"""
        start_color = self.current_color
        target_color = self.target_color
        
        start_time = time.time()
        duration = config.LED_FADE_DURATION
        update_interval = 1.0 / config.LED_UPDATE_RATE
        
        print(f"🌈 Fading from RGB{start_color} to RGB{target_color}")
        
        while self.is_fading and self.running:
            elapsed = time.time() - start_time
            progress = min(elapsed / duration, 1.0)
            
            # Linear interpolation between colors
            r = int(start_color[0] + (target_color[0] - start_color[0]) * progress)
            g = int(start_color[1] + (target_color[1] - start_color[1]) * progress)
            b = int(start_color[2] + (target_color[2] - start_color[2]) * progress)
            
            self.current_color = (r, g, b)
            
            # Update LED hardware
            if WS281X_AVAILABLE and self.strip:
                for i in range(self.strip.numPixels()):
                    self.strip.setPixelColor(i, Color(r, g, b))
                self.strip.show()
            
            # Check if fade is complete
            if progress >= 1.0:
                break
            
            time.sleep(update_interval)
        
        self.is_fading = False
        print(f"✅ Fade complete: RGB{self.current_color}")
    
    def set_brightness(self, brightness):
        """
        Adjust LED brightness
        
        Args:
            brightness (float): Brightness level from 0.0 to 1.0
        """
        brightness = max(0.0, min(1.0, brightness))
        
        if WS281X_AVAILABLE and self.strip:
            self.strip.setBrightness(int(brightness * 255))
            self.strip.show()
        else:
            print(f"💡 LED brightness set to {int(brightness * 100)}%")
    
    def turn_off(self, fade=True):
        """
        Turn off all LEDs
        
        Args:
            fade (bool): Whether to fade out or turn off instantly
        """
        self.set_color((0, 0, 0), fade=fade)
    
    def cleanup(self):
        """Clean up and turn off LEDs"""
        self.running = False
        
        if self.fade_thread and self.fade_thread.is_alive():
            self.is_fading = False
            self.fade_thread.join(timeout=2.0)
        
        # Turn off all LEDs
        if WS281X_AVAILABLE and self.strip:
            for i in range(self.strip.numPixels()):
                self.strip.setPixelColor(i, Color(0, 0, 0))
            self.strip.show()
        
        print("✅ LEDs turned off")


# Singleton instance
_led_controller = None


def get_led_controller():
    """Get or create LEDController singleton"""
    global _led_controller
    if _led_controller is None:
        _led_controller = LEDController()
    return _led_controller


def cleanup():
    """Clean up LED resources"""
    if _led_controller:
        _led_controller.cleanup()
