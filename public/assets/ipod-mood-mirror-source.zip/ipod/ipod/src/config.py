"""
Configuration file for iPod Mood Mirror
Contains mood mappings, GPIO pins, colors, and system settings
"""

# === MOOD CONFIGURATION ===
MOODS = {
    'jazz': {
        'name': 'Jazz',
        'color': (255, 140, 0),      # Orange RGB
        'button_pin': 17,             # GPIO pin for Jazz button
        'playlist_folder': 'music/jazz'
    },
    'chill': {
        'name': 'Chill R&B',
        'color': (255, 0, 0),         # Red RGB
        'button_pin': 27,             # GPIO pin for Chill button
        'playlist_folder': 'music/chill'
    },
    'happy': {
        'name': 'Happy',
        'color': (255, 255, 0),       # Yellow RGB
        'button_pin': 22,             # GPIO pin for Happy button
        'playlist_folder': 'music/happy'
    },
    'arabic': {
        'name': 'Arabic',
        'color': (128, 0, 128),       # Purple RGB
        'button_pin': 23,             # GPIO pin for Arabic button
        'playlist_folder': 'music/arabic'
    }
}

# === GPIO PIN CONFIGURATION ===
# Volume knob (rotary encoder)
VOLUME_CLK_PIN = 5   # Rotary encoder CLK
VOLUME_DT_PIN = 6    # Rotary encoder DT
VOLUME_SW_PIN = 13   # Rotary encoder switch (optional)

# LED strip control
LED_PIN = 18         # GPIO pin for LED data (PWM capable for RGB)
LED_COUNT = 60       # Number of LEDs in strip (adjust based on actual installation)

# === LED CONFIGURATION ===
LED_BRIGHTNESS = 0.5       # Default brightness (0.0 - 1.0)
LED_FADE_DURATION = 1.5    # Fade transition duration in seconds
LED_UPDATE_RATE = 60       # LED update frequency (Hz)

# === AUDIO CONFIGURATION ===
DEFAULT_VOLUME = 0.7       # Initial volume (0.0 - 1.0)
VOLUME_STEP = 0.05         # Volume change per knob click
AUDIO_SAMPLE_RATE = 44100  # Sample rate for audio playback

# === BUTTON CONFIGURATION ===
BUTTON_DEBOUNCE_TIME = 0.3  # Debounce delay in seconds
BUTTON_PULL_UP = True       # Use internal pull-up resistors

# === SYSTEM SETTINGS ===
STARTUP_MOOD = 'chill'      # Default mood on startup
MUSIC_BASE_PATH = 'music'   # Base folder for all playlists
SHUFFLE_ON_START = True     # Shuffle playlist when changing moods
CONTINUOUS_PLAYBACK = True  # Loop through playlist continuously

# === HARDWARE MODE ===
# Set to False for development/testing without GPIO hardware
HARDWARE_MODE = False

# If HARDWARE_MODE is False, simulate hardware for testing
SIMULATE_HARDWARE = not HARDWARE_MODE
