/*
 * iPod Mood Mirror - Arduino Button Controller
 * 
 * Connects 4 mood buttons and a rotary encoder to Arduino
 * Sends button presses to laptop via USB serial
 * 
 * Hardware Connections:
 * - Button 1 (Jazz)   → Pin 2 → GND
 * - Button 2 (Chill)  → Pin 3 → GND  
 * - Button 3 (Happy)  → Pin 4 → GND
 * - Button 4 (Arabic) → Pin 5 → GND
 * - Encoder CLK       → Pin 6
 * - Encoder DT        → Pin 7
 * - All use internal pull-ups
 */

// Button pins
const int BUTTON_JAZZ = 2;
const int BUTTON_CHILL = 3;
const int BUTTON_HAPPY = 4;
const int BUTTON_ARABIC = 5;

// Rotary encoder pins
const int ENCODER_CLK = 6;
const int ENCODER_DT = 7;

// Debounce timing
unsigned long lastDebounceTime[4] = {0, 0, 0, 0};
unsigned long debounceDelay = 50;  // 50ms debounce

// Previous button states
int lastButtonState[4] = {HIGH, HIGH, HIGH, HIGH};

// Encoder state
int encoderCLKLast = HIGH;

void setup() {
  // Initialize serial communication
  Serial.begin(9600);
  
  // Set up button pins with internal pull-up resistors
  pinMode(BUTTON_JAZZ, INPUT_PULLUP);
  pinMode(BUTTON_CHILL, INPUT_PULLUP);
  pinMode(BUTTON_HAPPY, INPUT_PULLUP);
  pinMode(BUTTON_ARABIC, INPUT_PULLUP);
  
  // Set up encoder pins
  pinMode(ENCODER_CLK, INPUT_PULLUP);
  pinMode(ENCODER_DT, INPUT_PULLUP);
  
  // Read initial encoder state
  encoderCLKLast = digitalRead(ENCODER_CLK);
  
  // Ready message
  delay(1000);
  Serial.println("READY");
}

void loop() {
  // Check mood buttons
  checkButton(0, BUTTON_JAZZ, "jazz");
  checkButton(1, BUTTON_CHILL, "chill");
  checkButton(2, BUTTON_HAPPY, "happy");
  checkButton(3, BUTTON_ARABIC, "arabic");
  
  // Check rotary encoder
  checkEncoder();
  
  delay(10);  // Small delay for stability
}

void checkButton(int index, int pin, const char* mood) {
  int reading = digitalRead(pin);
  
  // If button state changed
  if (reading != lastButtonState[index]) {
    lastDebounceTime[index] = millis();
  }
  
  // If enough time has passed since last change
  if ((millis() - lastDebounceTime[index]) > debounceDelay) {
    // If button is now pressed (LOW because of pull-up)
    if (reading == LOW && lastButtonState[index] == HIGH) {
      // Send mood command to laptop
      Serial.print("MOOD:");
      Serial.println(mood);
    }
  }
  
  lastButtonState[index] = reading;
}

void checkEncoder() {
  int encoderCLK = digitalRead(ENCODER_CLK);
  
  // If encoder has been rotated
  if (encoderCLK != encoderCLKLast) {
    int encoderDT = digitalRead(ENCODER_DT);
    
    // Determine direction
    if (encoderDT != encoderCLK) {
      // Clockwise (volume up)
      Serial.println("VOLUME:+1");
    } else {
      // Counter-clockwise (volume down)
      Serial.println("VOLUME:-1");
    }
  }
  
  encoderCLKLast = encoderCLK;
}
