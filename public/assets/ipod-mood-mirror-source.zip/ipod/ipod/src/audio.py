"""
Audio playback system for iPod Mood Mirror
Handles MP3 playlists with shuffle and volume control
"""

import os
import random
import pygame
from src import config


class AudioPlayer:
    """Manages music playback with playlist support"""
    
    def __init__(self):
        # Initialize pygame mixer
        pygame.mixer.init(frequency=config.AUDIO_SAMPLE_RATE)
        
        self.current_mood = None
        self.current_playlist = []
        self.current_track_index = 0
        self.volume = config.DEFAULT_VOLUME
        self.is_playing = False
        
        # Set initial volume
        pygame.mixer.music.set_volume(self.volume)
        
        # Setup end of track event
        pygame.mixer.music.set_endevent(pygame.USEREVENT + 1)
        
        print("✅ Audio player initialized")
    
    def load_playlist(self, mood_key):
        """
        Load playlist for a specific mood
        
        Args:
            mood_key (str): Mood identifier (e.g., 'jazz', 'chill')
        
        Returns:
            bool: True if playlist loaded successfully
        """
        if mood_key not in config.MOODS:
            print(f"❌ Invalid mood: {mood_key}")
            return False
        
        mood_data = config.MOODS[mood_key]
        playlist_folder = mood_data['playlist_folder']
        
        # Get all MP3 files from the playlist folder
        self.current_playlist = self._scan_music_folder(playlist_folder)
        
        if not self.current_playlist:
            print(f"⚠️  No MP3 files found in {playlist_folder}")
            return False
        
        self.current_mood = mood_key
        self.current_track_index = 0
        
        # Shuffle if enabled
        if config.SHUFFLE_ON_START:
            random.shuffle(self.current_playlist)
            print(f"🔀 Playlist shuffled ({len(self.current_playlist)} tracks)")
        
        print(f"✅ Loaded {mood_data['name']} playlist: {len(self.current_playlist)} tracks")
        return True
    
    def _scan_music_folder(self, folder_path):
        """
        Scan folder for MP3 files
        
        Args:
            folder_path (str): Path to music folder
        
        Returns:
            list: List of full paths to MP3 files
        """
        playlist = []
        
        if not os.path.exists(folder_path):
            print(f"⚠️  Folder does not exist: {folder_path}")
            return playlist
        
        for filename in os.listdir(folder_path):
            if filename.lower().endswith('.mp3'):
                full_path = os.path.join(folder_path, filename)
                playlist.append(full_path)
        
        return sorted(playlist)
    
    def play(self):
        """Start playing the current track"""
        if not self.current_playlist:
            print("❌ No playlist loaded")
            return False
        
        track_path = self.current_playlist[self.current_track_index]
        track_name = os.path.basename(track_path)
        
        try:
            pygame.mixer.music.load(track_path)
            pygame.mixer.music.play()
            self.is_playing = True
            print(f"▶️  Playing: {track_name}")
            return True
        except Exception as e:
            print(f"❌ Error playing {track_name}: {e}")
            return False
    
    def stop(self):
        """Stop playback"""
        pygame.mixer.music.stop()
        self.is_playing = False
        print("⏹️  Playback stopped")
    
    def pause(self):
        """Pause playback"""
        pygame.mixer.music.pause()
        self.is_playing = False
        print("⏸️  Playback paused")
    
    def unpause(self):
        """Resume playback"""
        pygame.mixer.music.unpause()
        self.is_playing = True
        print("▶️  Playback resumed")
    
    def next_track(self):
        """Skip to next track in playlist"""
        if not self.current_playlist:
            return False
        
        self.current_track_index += 1
        
        # Loop back to start if at end
        if self.current_track_index >= len(self.current_playlist):
            if config.CONTINUOUS_PLAYBACK:
                self.current_track_index = 0
                print("🔁 Playlist looping")
            else:
                print("⏹️  Playlist ended")
                self.stop()
                return False
        
        return self.play()
    
    def previous_track(self):
        """Go to previous track in playlist"""
        if not self.current_playlist:
            return False
        
        self.current_track_index -= 1
        
        # Loop to end if at start
        if self.current_track_index < 0:
            self.current_track_index = len(self.current_playlist) - 1
        
        return self.play()
    
    def set_volume(self, volume):
        """
        Set playback volume
        
        Args:
            volume (float): Volume level from 0.0 to 1.0
        """
        self.volume = max(0.0, min(1.0, volume))
        pygame.mixer.music.set_volume(self.volume)
        print(f"🔊 Volume: {int(self.volume * 100)}%")
    
    def adjust_volume(self, direction):
        """
        Adjust volume by step amount
        
        Args:
            direction (int): 1 to increase, -1 to decrease
        """
        new_volume = self.volume + (direction * config.VOLUME_STEP)
        self.set_volume(new_volume)
    
    def get_current_track_info(self):
        """
        Get information about the currently playing track
        
        Returns:
            dict: Track information or None
        """
        if not self.current_playlist or self.current_track_index >= len(self.current_playlist):
            return None
        
        track_path = self.current_playlist[self.current_track_index]
        return {
            'filename': os.path.basename(track_path),
            'path': track_path,
            'index': self.current_track_index + 1,
            'total': len(self.current_playlist),
            'mood': self.current_mood
        }
    
    def handle_track_end(self):
        """Handle when a track finishes playing"""
        if config.CONTINUOUS_PLAYBACK:
            self.next_track()
        else:
            self.stop()
    
    def cleanup(self):
        """Clean up audio resources"""
        self.stop()
        pygame.mixer.quit()
        print("✅ Audio player cleaned up")


# Singleton instance
_audio_player = None


def get_audio_player():
    """Get or create AudioPlayer singleton"""
    global _audio_player
    if _audio_player is None:
        _audio_player = AudioPlayer()
    return _audio_player


def cleanup():
    """Clean up audio resources"""
    if _audio_player:
        _audio_player.cleanup()
